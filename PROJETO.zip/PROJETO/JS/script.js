let dados = [];

const ctx = document.getElementById('grafico');

const grafico = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [],
        datasets: [{
            label: 'Sensor',
            data: []
        }]
    }
});

function buscarDados() {
    fetch("http://localhost:1880/dados")
        .then(res => res.json())
        .then(data => {

            let valores = data.reverse();

            // 🔹 Valor atual
            let ultimo = valores[valores.length - 1];
            document.getElementById("valor").innerText = ultimo.valor;

            // 🔴 Cor dinâmica
            if (ultimo.valor > 80) {
                document.getElementById("valor").style.color = "red";
            } else {
                document.getElementById("valor").style.color = "white";
            }

            // 📊 Atualizar gráfico
            grafico.data.labels = valores.map(d =>
                new Date(d.data).toLocaleTimeString()
            );

            grafico.data.datasets[0].data = valores.map(d => d.valor);

            grafico.update();

            // 📋 Atualizar tabela
            let tabela = document.getElementById("tabela");
            tabela.innerHTML = "";

            valores.forEach(d => {
                tabela.innerHTML += `
                    <tr>
                        <td>${new Date(d.data).toLocaleString()}</td>
                        <td>${d.valor}</td>
                    </tr>
                `;
            });

        })
        .catch(err => console.error("Erro:", err));
}

// 🔁 Atualiza a cada 2 segundos
setInterval(buscarDados, 2000);

// Primeira execução
buscarDados();